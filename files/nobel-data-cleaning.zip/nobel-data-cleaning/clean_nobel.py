"""Clean the Nobel Prize laureates dataset.

Source: TidyTuesday 2019-05-14 (nobel_winners.csv)
Run:    python clean_nobel.py
Reads:  data/raw/nobel_winners.csv
Writes: data/clean/nobel_winners_clean.csv, data/clean/country_mapping.csv,
        data/clean/cleaning_log.csv
"""
import html
import re
from pathlib import Path

import pandas as pd

RAW = Path("data/raw/nobel_winners.csv")
OUT = Path("data/clean")
OUT.mkdir(parents=True, exist_ok=True)

log = []  # (step, issue, rows_or_cells_affected, action)


def note(step, issue, n, action):
    log.append({"step": step, "issue": issue, "affected": int(n), "action": action})


df = pd.read_csv(RAW)
n_raw = len(df)
text_cols = df.select_dtypes(include=["object", "string"]).columns.tolist()

# ---------------------------------------------------------------- 1. text
# HTML entities (e.g. W&uuml;rttemberg, Unit&eacute; Mixte) -> real characters
changed = 0
for c in text_cols:
    s = df[c].dropna()
    fixed = s.map(html.unescape)
    changed += int((fixed != s).sum())
    df.loc[s.index, c] = fixed
note("text", "HTML entities in text fields", changed, "html.unescape on all text columns")

# whitespace + stray wrapping quotes
for c in text_cols:
    s = df[c].dropna()
    fixed = s.str.strip().str.replace(r"\s+", " ", regex=True)
    df.loc[s.index, c] = fixed
q = df["motivation"].dropna()
unq = q.str.replace(r'^"|"$', "", regex=True)
note("text", "motivation wrapped in literal double quotes", (unq != q).sum(), "stripped surrounding quotes")
df.loc[q.index, "motivation"] = unq

# ---------------------------------------------------------------- 2. types
df["prize_year"] = df["prize_year"].astype("int64")
df["laureate_id"] = df["laureate_id"].astype("int64")
for c in ["birth_date", "death_date"]:
    parsed = pd.to_datetime(df[c], format="%Y-%m-%d", errors="coerce")
    bad = df[c].notna() & parsed.isna()
    note("types", f"{c} stored as text", df[c].notna().sum(), "converted to datetime64 (ISO YYYY-MM-DD)")
    if bad.any():
        note("types", f"{c} unparseable", bad.sum(), "set to missing")
    df[c] = parsed
for c in ["category", "laureate_type", "gender"]:
    df[c] = df[c].astype("category")

# prize_share "1/3" -> numeric fraction (usable in arithmetic)
parts = df["prize_share"].str.split("/", expand=True).astype(float)
df["prize_share_fraction"] = (parts[0] / parts[1]).round(4)
note("types", "prize_share stored as text ('1/3')", len(df), "added numeric prize_share_fraction; kept original text")

# ---------------------------------------------------------------- 3. consistency
# 4 people labelled 'Organization' (they have gender + birth date)
mis = (df["laureate_type"] == "Organization") & df["gender"].notna()
note("consistency", "persons labelled laureate_type='Organization'", mis.sum(),
     "relabelled as 'Individual' (Le Duc Tho, Mother Teresa, Dalai Lama, Aung San Suu Kyi)")
df["laureate_type"] = df["laureate_type"].astype(object)
df.loc[mis, "laureate_type"] = "Individual"
df["laureate_type"] = df["laureate_type"].astype("category")


def modern_country(name):
    """'Prussia (Poland)' -> 'Poland'; 'West Germany (Germany)' -> 'Germany'."""
    if pd.isna(name):
        return name
    m = re.search(r"now ([^)]+)\)$", name)  # 'Alsace (then Germany, now France)'
    if m:
        return m.group(1)
    m = re.search(r"\(([^()]+)\)$", name)  # last parenthesised = present-day country
    out = m.group(1) if m else name
    special = {
        "Federal Republic of Germany": "Germany",
        "East Germany": "Germany",
        "People's Republic of China": "China",
        "Republic of Macedonia": "North Macedonia",
        "East Timor": "Timor-Leste",
    }
    return special.get(out, out)


mapping = []
for c in ["birth_country", "death_country", "organization_country"]:
    orig = df[c].copy()
    df[c] = orig.map(modern_country)
    ch = orig.notna() & (orig != df[c])
    note("consistency", f"{c}: historical/variant country names", ch.sum(), "mapped to present-day country name")
    mapping += list(zip(orig[ch], df.loc[ch, c]))
pd.DataFrame(sorted(set(mapping)), columns=["original", "cleaned"]).to_csv(OUT / "country_mapping.csv", index=False)

# ---------------------------------------------------------------- 4. duplicates
exact = df.duplicated().sum()
note("duplicates", "fully identical rows", exact, "none found" if exact == 0 else "dropped")
df = df.drop_duplicates()

# Same laureate + same prize repeated once per affiliation (identical in every non-organization column)
key = ["laureate_id", "prize_year", "category"]
org_cols = ["organization_name", "organization_city", "organization_country"]
dup_mask = df.duplicated(key, keep="first")
others = (
    df[df.duplicated(key, keep=False)]
    .assign(aff=lambda x: x["organization_name"].fillna("") + " (" + x["organization_city"].fillna("") + ", " + x["organization_country"].fillna("") + ")")
    .groupby(key)["aff"].apply(lambda s: " | ".join(s.iloc[1:]))
    .rename("other_affiliations")
)
df = df.join(others, on=key)
df = df[~dup_mask].copy()
note("duplicates", "laureate-prize repeated per affiliation", dup_mask.sum(),
     "collapsed to one row per laureate per prize; first affiliation kept, extras in other_affiliations")

# ---------------------------------------------------------------- 5. missing values
# Not imputed: absence is meaningful (alive laureates, organisations, early Peace prizes)
for c in ["motivation", "birth_date", "death_date", "organization_name"]:
    note("missing", f"{c} missing", df[c].isna().sum(), "left as missing (not applicable / unknown); not imputed")
df["is_living"] = df["death_date"].isna()
note("missing", "death_date blank means still living (or unknown)", df["is_living"].sum(), "added is_living flag")

# derived helper
df["age_at_award"] = (df["prize_year"] - df["birth_date"].dt.year).astype("Int64")

# ---------------------------------------------------------------- 6. validation
assert not df.duplicated(key).any()
both = df["death_date"].notna() & df["birth_date"].notna()
assert (df.loc[both, "death_date"] >= df.loc[both, "birth_date"]).all()
assert df["prize_share_fraction"].between(0, 1).all()

df = df.sort_values(["prize_year", "category", "laureate_id"]).reset_index(drop=True)
df.to_csv(OUT / "nobel_winners_clean.csv", index=False, date_format="%Y-%m-%d")
pd.DataFrame(log).to_csv(OUT / "cleaning_log.csv", index=False)
print(f"rows: {n_raw} -> {len(df)}; columns: {df.shape[1]}")
print(pd.DataFrame(log).to_string(index=False))
